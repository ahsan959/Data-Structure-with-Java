class ReturnDemo6
{
	public static void main(String[] args)
	{
		ReturnDemo6 ob=new ReturnDemo6();
		ob.m1();
	}
	int m1()
	{
		System.out.println("hi");
		return 10;
		System.out.println("hello");
	}
}