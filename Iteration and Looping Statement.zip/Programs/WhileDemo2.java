class WhileDemo2
{
	public static void main(String[] args)
	{
		while()
		{
			System.out.println("hi");
		}
	}
}