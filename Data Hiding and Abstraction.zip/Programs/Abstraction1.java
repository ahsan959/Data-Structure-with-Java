class Xyz
{

}
abstract class A extends Xyz
{
	void sum()
	{

	}
	abstract void show();
	abstract void show(int a);
}
class B extends A
{
	void show()
	{

	}
	void show(int a)
	{

	}
}
class Abstraction1
{
	public static void main(String[] args)
	{
		A ob1;
		//A ob2=new A();
	}
}