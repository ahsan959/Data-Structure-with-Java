public class A
{
	public void showA()
	{
		System.out.println("i am in class A");
	}
}