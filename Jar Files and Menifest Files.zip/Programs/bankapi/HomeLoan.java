package in.smartprogramming.icici.loan.homeloan;

public class HomeLoan
{
	public void getHomeLoan()
	{
		System.out.println("home loan assigned");
	}
}