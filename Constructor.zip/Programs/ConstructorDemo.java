class ConstructorDemo
{
	ConstructorDemo()
	{

	}
	void show()
	{

	}
	public static void main(String[] args)
	{
		ConstructorDemo ob=new ConstructorDemo();
		ob.show();
	}
}