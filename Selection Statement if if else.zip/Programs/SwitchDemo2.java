class SwitchDemo2
{
	public static void main(String[] args)
	{
		String name="deepak";
		switch(name)
		{
			case "amit": System.out.println("101");
				  break;
			case "deepesh": System.out.println("102");
				  break;
			case "deepak": System.out.println("103");
				  break;
			case "rahul": System.out.println("104");
				  break;
			default: System.out.println("Invalid name");
				 break;
		}
	}
}