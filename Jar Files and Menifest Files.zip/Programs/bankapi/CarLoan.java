package in.smartprogramming.icici.loan.carloan;

public class CarLoan
{
	public void getCarLoan()
	{
		System.out.println("car loan assigned");
	}
}