interface I1
{
	void show1();
}
interface I2
{
	void show2();
}
interface I3
{

}
class A
{

}
class InterfaceDemo extends A implements I1, I2, I3
{
	public void show1()
	{

	}
	public void show2()
	{

	}
}