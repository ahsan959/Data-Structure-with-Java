/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo;

/**
 *
 * @author Deepak
 */
public class Test2
{
    public static void main(String[] args)
    {
        System.out.println("1");
        System.out.println("2");
        System.out.println("3");
        System.out.println(100/0);
        System.out.println("4");
        System.out.println("5");
        System.out.println("6");
    }
}
