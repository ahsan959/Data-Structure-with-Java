class IfDemo
{
	public static void main(String[] args)
	{
		int no1=10;
		int no2;
		
		if(no1==10)
		{
			no2=20;
			System.out.println("hello");
		}
		System.out.println(no2);
	}
}