/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multithreadingcases;

/**
 *
 * @author Deepak
 */
class Abc5 extends Thread
{
    
}
public class Test5
{
    public static void main(String[] args)
    {
        Abc5 ob1=new Abc5();
        ob1.start();
    }
}
