public class B
{
	public void showB()
	{
		System.out.println("i am in class B");
	}
}