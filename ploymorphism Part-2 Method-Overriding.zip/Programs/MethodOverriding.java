class Parent
{
	void marry()
	{
		System.out.println("arrange marriage");
	}
	void greet()
	{
		System.out.println("namaste");
	}
}
class Child extends Parent
{
	void marry()
	{
		System.out.println("love marriage");
	}
	void greet()
	{
		System.out.println("hello dude");
	}
}