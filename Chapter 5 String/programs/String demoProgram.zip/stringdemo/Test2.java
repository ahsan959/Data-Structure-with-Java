/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringdemo;

/**
 *
 * @author Deepak
 */
final class Test
{
    void greet()
    {
        System.out.println("hi");
    }
}
public class Test2 //extends Test
{
    void greet()
    {
        System.out.println("hello");
    }
    public static void main(String[] args)
    {
        
    }
}
