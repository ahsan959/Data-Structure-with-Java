class ReturnDemo5
{
	public static void main(String[] args)
	{
		ReturnDemo5 ob=new ReturnDemo5();
		ob.m1();
	}
	void m1()
	{
		System.out.println("hi");
		return;
	}
}