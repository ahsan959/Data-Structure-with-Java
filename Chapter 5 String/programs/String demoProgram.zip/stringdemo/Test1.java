/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stringdemo;

/**
 *
 * @author Deepak
 */
public class Test1 
{
    public static void main(String[] args)
    {
        String name="deepak";
        //name=name+" java";
        //name=name.concat(" java");
        name.concat(" java");
        System.out.println(name);
    }
}
