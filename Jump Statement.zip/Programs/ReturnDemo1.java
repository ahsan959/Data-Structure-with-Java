class ReturnDemo1
{
	public static void main(String[] args)
	{
		ReturnDemo1 ob=new ReturnDemo1();
		String s=ob.m1();
		System.out.println(s);
	}
	String m1()
	{
		return "deepak";
	}
}