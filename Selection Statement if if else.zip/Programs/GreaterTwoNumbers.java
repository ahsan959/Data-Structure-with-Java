class GreaterTwoNumbers
{
	public static void main(String[] args)
	{
		int no1=100;
		int no2=20;
		
		if(no1>no2)
		{
			System.out.println("no1 is greater");
		}
		else
		{
			System.out.println("no2 is greater");
		}
	}
}