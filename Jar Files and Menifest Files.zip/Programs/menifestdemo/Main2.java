import p1.*;

class Main2
{
	public static void main(String[] args)
	{
		A ob=new A();
		ob.showA();

		B ob2=new B();
		ob2.showB();
	}
}