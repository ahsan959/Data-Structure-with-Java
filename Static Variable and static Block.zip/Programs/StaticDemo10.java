class StaticDemo10
{
	static
	{
		System.out.println("hello");
	}
	public static void main(String[] args)
	{
		System.out.println("hi");
	}
}