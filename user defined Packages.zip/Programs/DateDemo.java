//import java.util.*;
//import java.sql.*;

class DateDemo
{
	public static void main(String[] args)
	{
		java.util.Date d1=new java.util.Date();

		java.sql.Date d2=new java.sql.Date(0,0,0);
	}
}