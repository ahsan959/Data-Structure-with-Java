class StaticDemo7
{
	static
	{
		System.out.println("i am in static block");
	}

	public static void main(String[] args)
	{
		System.out.println("i am in main method");
	}
}