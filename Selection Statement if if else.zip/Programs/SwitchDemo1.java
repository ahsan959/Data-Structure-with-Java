class SwitchDemo1
{
	public static void main(String[] args)
	{
		int rollno=113;
		switch(rollno)
		{
			case 101: System.out.println("Amit");
				  break;
			case 102: System.out.println("Deepesh");
				  break;
			case 103: System.out.println("Deepak");
				  break;
			case 104: System.out.println("Rahul");
				  break;
			default: System.out.println("Invalid roll no");
				 break;
		}
	}
}