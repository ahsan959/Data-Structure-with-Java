import javax.swing.JFrame;

class Test
{
	public static void main(String[] args)
	{
		JFrame jf=new JFrame();
		jf.setSize(400,400);
		jf.setVisible(true);
	}
}