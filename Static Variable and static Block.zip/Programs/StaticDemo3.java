class StaticDemo3
{
	static int no1=10;

	void m1()
	{
		static int no2=20;
	}
	public static void main(String[] args)
	{
		
	}
}