class Aa
{

}
final class A extends Aa
{
	
}
class B //extends A
{
	
}
class FinalTest3
{
	public static void main(String[] args)
	{
		
	}
}