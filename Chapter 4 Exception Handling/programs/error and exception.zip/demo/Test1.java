/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo;

/**
 *
 * @author Deepak
 */
public class Test1 
{
    int rollno=10;
    public static void main(String[] args)
    {
        int a=10,b=20;
        int c=a+b;
        
        String s1="abc", s2="xyz";
        String ss=s1+s2;
        
        char c1='a', c2='b';
        //char cc=c1+c2;
    }
}
