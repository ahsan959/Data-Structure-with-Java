interface I1
{
	static void show()
	{
		System.out.println("i am static method");
	}
}
class InterfaceNewFeatures2
{
	public static void main(String[] args)
	{
		I1.show();
	}
}