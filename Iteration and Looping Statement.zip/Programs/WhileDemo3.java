class WhileDemo3
{
	public static void main(String[] args)
	{
		while(true)
		{
			System.out.println("hi");
		}
		System.out.println("hello");
	}
}