abstract class AbstractClassDemo
{
	int a;

	abstract void show();
}