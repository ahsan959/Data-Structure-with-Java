class ReturnDemo3
{
	public static void main(String[] args)
	{
		ReturnDemo3 ob=new ReturnDemo3();
		int s=ob.m1();
		System.out.println(s);
	}
	void m1()
	{
		int no1=10, no2=20;
	}
}