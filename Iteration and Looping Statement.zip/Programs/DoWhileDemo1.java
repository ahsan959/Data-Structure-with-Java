class DoWhileDemo1
{
	public static void main(String[] args)
	{
		int i=1;
		do
		{
			System.out.println("hello");
			i=i+1;
		}
		while(i<=5);
	}
}