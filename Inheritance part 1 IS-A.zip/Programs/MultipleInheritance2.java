interface A
{
	void show1();
}
interface B
{
	void show1();
}
class C implements A,B
{
	void show1()
	{

	}
}
class MultipleInheritance2
{
	public static void main(String[] args)
	{

	}
}