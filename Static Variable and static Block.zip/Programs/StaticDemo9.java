
class StaticDemo9
{
	static
	{
		System.out.println("i am in static block class staticdemo 1");
	}

	public static void main(String[] args)
	{
		System.out.println("i am in main method");
	}

	static
	{
		System.out.println("i am in static block class staticdemo 2");
	}
}