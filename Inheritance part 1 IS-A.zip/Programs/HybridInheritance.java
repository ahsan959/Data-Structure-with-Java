interface I1
{

}
interface I2
{

}
class B
{

}
class C extends B implements I1, I2
{

}