import p1.A;

class Main
{
	public static void main(String[] args)
	{
		A ob=new A();
		ob.showA();
	}
}