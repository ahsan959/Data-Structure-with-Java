
class A
{
	static int a=10;
	static void show2()
	{
		System.out.println(a);
	}
}
class StaticMethodsDemo4
{

	public static void main(String[] args)
	{
		A.show2();
	}
}