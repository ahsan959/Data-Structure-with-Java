class Swap1
{
	public static void main(String[] args)
	{
		int no1=10, no2=20;

		int temp=no1;
		no1=no2;
		no2=temp;

		System.out.println("no1 : "+no1);
		System.out.println("no2 : "+no2);
	}
}