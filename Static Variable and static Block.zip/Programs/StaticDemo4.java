class StaticDemo4
{
	static void m1()
	{
		//static int no2=20;
		int no=10;
	}
	public static void main(String[] args)
	{
		
	}
}