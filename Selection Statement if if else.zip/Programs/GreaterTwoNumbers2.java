class GreaterTwoNumbers2
{
	public static void main(String[] args)
	{
		int no1=100;
		int no2=20;
		
		int res = (no1>no2) ? no1 : no2;
		System.out.println(res+" is greater");
	}
}